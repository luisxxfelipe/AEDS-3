#include <string.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct arvore_avl
{
    char palavra[20];
    struct arvore_avl *Esquerda; //  Ponteiro para acessar os elemento a esquerda da raiz
    struct arvore_avl *Direita;  //  Ponteiro para acessar os elementos a direita da raiz
    int altura;
    int prioridade;
} s_arvore;

typedef struct fila_prioridade
{
    int quantidade;
    s_arvore *word;
} s_fila;

// parte da arvore avl
s_arvore *inicializacao();
s_arvore *RotDir(s_arvore *raiz);
s_arvore *RotEsq(s_arvore *raiz);
s_arvore remover_avl(s_arvore *raiz, s_fila *fila);
s_arvore *inserir_arvore(s_arvore *raiz, char palavra[20]);
int contador_palavras();
int altura(s_arvore *raiz);
int Maior(int a, int b);
int Balanceamento(s_arvore *raiz);
void remover_caracteres();
void in_ordem(s_arvore *raiz);

// parte da fila de prioridade
s_fila *criar_fila();
int inserir_fila(s_fila *fila, char palavras[], int prioridade);
int remover_fila(s_fila *fila, char remover[], int *prioridade);
void rebaixar_elemento_fila(s_fila *fila, int pai);
void promover_elemento_fila(s_fila *fila, int filho);
void imprime_Fila(s_fila *fila);

int main()
{
    FILE *arquivo = fopen("livro2.txt", "r");
    remover_caracteres();
    rewind(arquivo);
    s_arvore *arvore = inicializacao();
    s_fila *fila = criar_fila();
    int contador = contador_palavras();
    int opcao, i, prioridade = 0;
    char palavra[20];

    for (i = 0; i < contador; i++)
    {
        fscanf(arquivo, "%s", palavra);
        arvore = inserir_arvore(arvore, palavra);
        // printf("\nA palavra [%s] foi inserida com sucesso na arvore.\n", palavra);
    }

    in_ordem(arvore);
    remover_avl(arvore, fila);
    do
    {

        printf("\n[1]Remover o elemento da fila de prioridade.\n[2]Imprimir todos os elementos da arvore AVL.\n[3]Quantidade de palavras dentro do arquivo.\n");
        printf("\nDigite a opcao desejada: ");
        scanf("%d", &opcao);

        if (opcao == 1)
        {

            remover_fila(fila, palavra, &prioridade);
            printf("\nA palavra [%s] de prioridade [%d] foi removida da fila.\n", palavra, prioridade);
        }

        if (opcao == 2)
        {
            imprime_Fila(fila);
        }

        if (opcao == 3)
        {
            printf("\nO arquivo possui [%d] palavras.\n", contador);
        }

        fclose(arquivo);

    } while (opcao != 4);
    return 0;
}

void remover_caracteres() // funcao para remover os caracteres especiais
{
    FILE *arquivo = fopen("livro2.txt", "r+");

    int i, tam, j = 0;
    char frase[400000], novo[400000];

    fscanf(arquivo, "%400000c", frase);
    tam = strlen(frase); // strlen retorna o cumprimento da string

    if (arquivo == NULL)
    {
        printf("Ocorreu um erro na abertura do arquivo, tente novamente!!");
        getchar();
        exit(1);
    }

    for (i = 0; i < tam; i++) // percorre todo laço e verifica se possui algum caractere especial e o remove
    {
        if ((frase[i] != '.') && (frase[i] != '<') && (frase[i] != '>') && (frase[i] != '*') && frase[i] != '\'' && (frase[i] != '(') && (frase[i] != '$') && (frase[i] != ')') && (frase[i] != ':') && (frase[i] != '?') && (frase[i] != ',') && (frase[i] != '-') && (frase[i] != '_') && (frase[i] != '@') && (frase[i] != '!') && (frase[i] != '"') && (frase[i] != '/') && (frase[i] != ';'))
        {
            novo[j] = frase[i];
            j++;
            novo[j] = ' ';
        }
    }
    fclose(arquivo);
    remove("livro2.txt");
    arquivo = fopen("livro2.txt", "w");
    fprintf(arquivo, novo);
    fclose(arquivo);
}

int contador_palavras() // funcao para contar as palavras dentro do arquivo
{
    FILE *file = fopen("livro2.txt", "r");
    rewind(file);
    int inicio_palavra = 0, palavras = 0, caracteres = 0;
    char caracter; // armazena o caracter
    while (!feof(file))
    {
        caracter = fgetc(file);
        caracteres++;
        if ((caracter != ' ') && (caracter != '\n') && (!inicio_palavra))
        {
            inicio_palavra = 1;
        }
        if (((caracter == ' ') || (caracter == '\n')) && (inicio_palavra))
        {
            inicio_palavra = 0;
            palavras++;
        }
    }

    return palavras;
}

s_arvore *inicializacao() // inicialização da arvore como NULL
{
    return NULL;
}

int altura(s_arvore *raiz) // retorna a altura da arvore
{
    if (raiz == NULL)    // Se raiz for nulo
        return -1;       // retorna 0
    return raiz->altura; // Senão usa recursividade
}

int Maior(int a, int b) // Função que retorna o maior valor entre dois inteiros (Utilizado pelas rotações
{
    return (a > b) ? a : b;
}

s_arvore *RotDir(s_arvore *raiz) // Função para a rotação da sub-árvore (à direita)
{
    s_arvore *AuxiliarEsquerda = raiz->Esquerda;
    s_arvore *AuxiliarDireita = AuxiliarEsquerda->Direita;

    // Realizando rotação
    AuxiliarEsquerda->Direita = raiz;
    raiz->Esquerda = AuxiliarDireita;

    // Atualizando alturas
    raiz->altura = Maior(altura(raiz->Esquerda), altura(raiz->Direita)) + 1;
    AuxiliarEsquerda->altura = Maior(altura(AuxiliarEsquerda->Esquerda), altura(AuxiliarEsquerda->Direita)) + 1;

    // Retornando a nova raiz (raiz alterada)
    return AuxiliarEsquerda;
}

s_arvore *RotEsq(s_arvore *raiz) // Função para a rotação da sub-árvore (à esquerda)
{
    s_arvore *AuxiliarDireita = raiz->Direita;
    s_arvore *AuxiliarEsquerda = AuxiliarDireita->Esquerda;

    // Realizando rotação
    AuxiliarDireita->Esquerda = raiz;
    raiz->Direita = AuxiliarEsquerda;

    // Atualizando alturas
    raiz->altura = Maior(altura(raiz->Esquerda), altura(raiz->Direita)) + 1;
    AuxiliarDireita->altura = Maior(altura(AuxiliarDireita->Esquerda), altura(AuxiliarDireita->Direita)) + 1;

    // Retornando a nova raiz (raiz alterada)
    return AuxiliarDireita;
}

int Balanceamento(s_arvore *raiz) // Função que retorna o fator de balanceamento do nó
{
    if (raiz != NULL)
        return 0;
    return altura(raiz->Esquerda) - altura(raiz->Direita);
}

s_arvore *inserir_arvore(s_arvore *raiz, char palavra[20]) // Função que insere um novo Nó - Utiliza a função auxiliar NovoNo
{
    // Passo 1 - Executa a inserção normal
    if (raiz == NULL) // Se a raiz é nula(Vazia)
    {
        s_arvore *raiz = (s_arvore *)malloc(sizeof(s_arvore)); // Aloca espaço na memória para o registro
        strcpy(raiz->palavra, palavra);                        // palavra de raiz recebe a chave informada pelo usuário
        raiz->Esquerda = NULL;                                 // Como o nó é novo -> Esquerda e -> Direita apontam para nulo
        raiz->Direita = NULL;
        raiz->altura = 0; // O novo nó inserido é inicialmente uma folha portanto sua altura é 1
        raiz->prioridade = 1;
    }

    else if (raiz != NULL) // Se a raiz não for nula(Vazia)
    {
        if (strcmp(palavra, raiz->palavra) < 0) // Verifica se a chave informada pelo usuário é menor que a chave da raiz
        {
            raiz->Esquerda = inserir_arvore(raiz->Esquerda, palavra); // se for menor, chama novamente a função(recursividade), fazendo a última chave(esquerda) apontar para a nova chave
        }
        // Senão (veja linha abaixo)
        if (strcmp(palavra, raiz->palavra) > 0) // Verifica se a chave informada pelo usuário é maior que a chave da raiz
        {
            raiz->Direita = inserir_arvore(raiz->Direita, palavra); // senão for menor, é maior e chama novamente a função(recursividade), fazendo a última chave(direita) apontar para a nova chave
        }

        if (strcmp(palavra, raiz->palavra) == 0)
        {
            raiz->prioridade++;
        }

        // Passo 2 - Atualiza a altura do novo nó (em relação ao anterior)
        raiz->altura = Maior(altura(raiz->Esquerda), altura(raiz->Direita)) + 1;

        // Passo 3 - Declarada uma váriável inteira que tem por objetivo obter o fator de balanceamento deste nó em relação ao anterior(pai) para saber se a arvore ficou desbalanceada
        int fb = Balanceamento(raiz); // Verifica o fator de balanceamento

        // Se o novo nó causou desbalanceamento da árvore, será necessário obter o balanceamento por meio de uma das 4 formas (dependendo do caso)

        // Rotação simples à esquerda
        if (fb > 1 && palavra < raiz->Esquerda->palavra) // Se o fator de balanceamento da raiz for maior que 1 e o palavra informado pelo usuário for menor que o palavra que está na raiz -> Esquerda
            return RotDir(raiz);                         // Retorna a raiz, depois de aplicada a Rotação à Direita(Função)

        // Rotação simples à direita
        if (fb < -1 && palavra > raiz->Direita->palavra)
            return RotEsq(raiz);

        // Rotação dupla à esquerda
        if (fb > 1 && palavra > raiz->Esquerda->palavra)
        {
            raiz->Esquerda = RotEsq(raiz->Esquerda);
            return RotDir(raiz);
        }

        // Rotação dupla à direita
        if (fb < -1 && palavra < raiz->Direita->palavra)
        {
            raiz->Direita = RotDir(raiz->Direita);
            return RotEsq(raiz);
        } // Fim das rotações

        // Passo 4 - Retorna a nova raiz(alterada)
        return raiz;
    }
}

void in_ordem(s_arvore *raiz) 
{
    if (raiz == (s_arvore *)NULL) // Se o ponteiro raiz do tipo s_arvore(registro) for nulo
        return;                   // Retorna nulo
    // Senão
    in_ordem(raiz->Esquerda);        // Se não chama novamente a função indo para a esquerda
    printf("%s \n ", raiz->palavra); // Imprimindo o palavra
    in_ordem(raiz->Direita);         // E depois chamando novamente a função indo para a direita
}

s_fila *criar_fila() // funcao para alocar e criar a fila
{
    s_fila *fila = (s_fila *)malloc(sizeof(s_fila));
    int tamanho = contador_palavras();
    fila->word = (s_arvore *)malloc(sizeof(s_arvore) * tamanho);
    fila->quantidade = 0;
    return fila;
}

s_arvore remover_avl(s_arvore *raiz, s_fila *fila) // funcao que remove o elemento da arvore e insere na fila
{
    if (raiz != NULL)
    {
        remover_avl(raiz->Esquerda, fila);
        inserir_fila(fila, raiz->palavra, raiz->prioridade);
        remover_avl(raiz->Direita, fila);
        free(raiz);
    }
}

int inserir_fila(s_fila *fila, char palavras[], int prioridade) // funcao para inserir o elemento na fila de prioridade
{
    strcpy(fila->word[fila->quantidade].palavra, palavras); // o nome que eu quero inserir vai para o campo word na posicao apontada para o valor de quantidade
    fila->word[fila->quantidade].prioridade = prioridade;   // prioridade vai passsar a assumir na ultima posicao vaga
    promover_elemento_fila(fila, fila->quantidade);         // balanceamento e inserindo cada elemento no seu devido lugar
    fila->quantidade++;                                     // aumenta a quantidade de elementos na fila
    return 1;
}

void promover_elemento_fila(s_fila *fila, int filho) // funcao para verificar o balanceamento da remocao
{
    int pai;
    s_arvore aux;
    pai = (filho - 1) / 2;                                                            // posicao do pai do filho dentro do vetor
    while ((filho > 0) && fila->word[pai].prioridade <= fila->word[filho].prioridade) // se a prioridade do filho for maior que a do pai
    {
        aux = fila->word[filho];             // troca de lugar o filho e o pai de lugar, aux para receber filho
        fila->word[filho] = fila->word[pai]; // pega os dados do pai e copia na posicao do filho e assim faz a troca de elementos
        fila->word[pai] = aux;
        filho = pai;         // valor que era do pai se torna a do filho
        pai = (pai - 1) / 2; // calcula a nova posicao do pai
    }
}

int remover_fila(s_fila *fila, char remover[], int *prioridade) // função para remover o elemento da fila
{
    if (fila->quantidade == 0)
        return 0;

    strcpy(remover, fila->word[0].palavra); // valor que ta na posicao quantidade e copia para a posicao 0 da fila, troca os elementos
    *prioridade = fila->word[0].prioridade;
    fila->word[0] = fila->word[fila->quantidade - 1]; // pega o ultimo elemento do vetor e poe no começo da fila
    fila->quantidade--;
    rebaixar_elemento_fila(fila, 0); // posicao que eu quero rebaixar

    return 1;
}

void rebaixar_elemento_fila(s_fila *fila, int pai) // função para rebaixar o elemento
{
    s_arvore aux;
    int filho = 2 * pai + 1;

    while (filho < fila->quantidade) // enquanto o filho for menor que a quantidade de elementos da filha
    {

        if (filho < fila->quantidade - 1) // signfica que ele tem um irmao

            // verifica qual dos dois é o maior
            if (fila->word[filho].prioridade < fila->word[filho + 1].prioridade) // se o irmao for menor que o irmao + 1

                filho++; // vai percorrer novamente ate achar o proximo filho, ate encontrar o filho com maior prioridade

        if (fila->word[pai].prioridade >= fila->word[filho].prioridade) // se o pai for >= filho, para
            break;

        aux = fila->word[pai]; // troca o pai de lugar
        fila->word[pai] = fila->word[filho];
        fila->word[filho] = aux; // filho vira pai e calcula novamente o filho
        pai = filho;
        filho = 2 * pai + 1;
    }
}

void imprime_Fila(s_fila *fila) // imprime os elementos de acordo com a fila de prioridade
{
    FILE *arquivo2 = fopen("dados_fila_prioridade.txt", "w");
    if (fila == NULL)
        return;
    for (int i = 0; i < fila->quantidade; i++)
    {
        printf("%d) Prioridade: %d \tNome: %s\n", i, fila->word[i].prioridade, fila->word[i].palavra);
        fprintf(arquivo2, "%d) Prioridade: %d \tNome: %s\n", i, fila->word[i].prioridade, fila->word[i].palavra);
    }

    fclose(arquivo2);
}
